package com.linu.Hibernatedb.DAOImp;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.linu.Hibernatedb.DbConfig;
import com.linu.Hibernatedb.DAOModel.CategoryModel;

public class CategoryImp {
	private Transaction trans;
	private Session sess;
	public void addCategory(CategoryModel c) {
		try
		{
			DbConfig db=new DbConfig();
			sess=db.getSess();
			trans=sess.beginTransaction();
			sess.save(c);//save is an Pre-define method
			trans.commit();
		}
		catch(Exception t)
		{
			System.out.println(t);
		}
}}
