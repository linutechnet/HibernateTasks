package com.linu.Hibernatedb.DAO;

import com.linu.Hibernatedb.DAOModel.UserModel;

public interface UserDAO {
	  public void addUser(UserModel u);
}
