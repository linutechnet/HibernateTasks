package com.linu.Hibernatedb;
import com.linu.Hibernatedb.DAOImp.CategoryImp;
import com.linu.Hibernatedb.DAOImp.ProductImp;
import com.linu.Hibernatedb.DAOImp.UserImp;
import com.linu.Hibernatedb.DAOModel.CategoryModel;
import com.linu.Hibernatedb.DAOModel.ProductModel;
import com.linu.Hibernatedb.DAOModel.UserModel;


	public class AppConfig {

		public static void main(String[] args) {
			
			ProductModel p=new ProductModel();
			p.setPid(1001);
			p.setPname("apple");
			p.setPprice(100);
			
			ProductImp pm=new ProductImp();
			pm.addProduct(p);
			
			CategoryModel c=new CategoryModel();
			c.setCid(1);
			c.setCname("book");
			
			CategoryImp cm=new CategoryImp();
			cm.addCategory(c);
			
			UserModel u=new UserModel();
			u.setUid(001);
			u.setUname("linu");
			u.setUaddress("Nagal Nagar");
			u.setUemail("linu@gmail.com");
			
		    UserImp um=new UserImp();
			um.addUser(u);
			
			System.out.println("Inserted Sucessfully!!");

		}

	}


