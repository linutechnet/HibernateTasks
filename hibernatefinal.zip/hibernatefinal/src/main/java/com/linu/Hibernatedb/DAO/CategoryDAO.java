package com.linu.Hibernatedb.DAO;

import com.linu.Hibernatedb.DAOModel.CategoryModel;

public interface CategoryDAO {
	  public void addCategory(CategoryModel c);
}
