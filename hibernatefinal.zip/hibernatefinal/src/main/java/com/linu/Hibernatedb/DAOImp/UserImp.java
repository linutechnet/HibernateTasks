package com.linu.Hibernatedb.DAOImp;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.linu.Hibernatedb.DbConfig;
import com.linu.Hibernatedb.DAOModel.UserModel;

public class UserImp {
	private Transaction trans;
	private Session sess;
	public void addUser(UserModel u) {
		try
		{
			DbConfig db=new DbConfig();
			sess=db.getSess();
			trans=sess.beginTransaction();
			sess.save(u);//save is an Pre-define method
			trans.commit();
		}
		catch(Exception t)
		{
			System.out.println(t);
		}
}}
