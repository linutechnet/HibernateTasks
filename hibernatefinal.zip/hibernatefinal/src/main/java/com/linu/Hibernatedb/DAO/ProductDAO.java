package com.linu.Hibernatedb.DAO;
import com.linu.Hibernatedb.DAOModel.ProductModel;
public interface ProductDAO 
{
    public void addProduct(ProductModel p);
}
