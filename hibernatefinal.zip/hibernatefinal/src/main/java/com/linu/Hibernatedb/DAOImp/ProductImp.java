package com.linu.Hibernatedb.DAOImp;
import com.linu.Hibernatedb.DAO.ProductDAO;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.linu.Hibernatedb.DbConfig;
import com.linu.Hibernatedb.DAOModel.ProductModel;

public class ProductImp {

	private Transaction trans;
	private Session sess;
	public void addProduct(ProductModel p) {
		try
		{
			DbConfig db=new DbConfig();
			sess=db.getSess();
			trans=sess.beginTransaction();
			sess.save(p);//save is an Pre-define method
			trans.commit();
		}
		catch(Exception t)
		{
			System.out.println(t);
		}
		
	}

}

